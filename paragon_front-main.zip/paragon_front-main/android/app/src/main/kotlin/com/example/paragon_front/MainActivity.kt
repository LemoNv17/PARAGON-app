package com.example.paragon_front

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
